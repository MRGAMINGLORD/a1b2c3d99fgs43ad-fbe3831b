const fs = require('fs');

let f = fs.readFileSync('src/App.tsx', 'utf8');

f = f.replace(/<div className=\{`p-3 bg-black\/40 border border-zinc-800 rounded-lg flex items-center justify-between \$\{isBackCloset \? 'glitch-card' : ''\}`\} style=\{isBackCloset \? \{ animationDuration: '10s', animationDelay: `\$\{idx \* 2\}s` \} : \{\}\}>/g, function() {
   if (!this.count) this.count = 0;
   const idx = this.count++;
   return `<div className={\`p-3 bg-black/40 border border-zinc-800 rounded-lg flex items-center justify-between \${isBackCloset ? 'glitch-card' : ''}\`} style={isBackCloset ? { animationDuration: '10s', animationDelay: '${idx * 2}s' } : {}}>`;
});

fs.writeFileSync('src/App.tsx', f);
