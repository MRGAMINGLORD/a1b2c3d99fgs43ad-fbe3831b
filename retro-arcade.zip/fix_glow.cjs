const fs = require('fs');

let css = fs.readFileSync('src/index.css', 'utf8');

css += `
@keyframes arcade-glow {
  0% { box-shadow: 0 0 80px -10px rgba(139, 92, 246, 0.4); }
  25% { box-shadow: 0 0 100px -5px rgba(236, 72, 153, 0.5); }
  50% { box-shadow: 0 0 120px 5px rgba(59, 130, 246, 0.6); }
  75% { box-shadow: 0 0 100px -5px rgba(16, 185, 129, 0.5); }
  100% { box-shadow: 0 0 80px -10px rgba(139, 92, 246, 0.4); }
}

.animate-arcade-glow {
  animation: arcade-glow 8s ease-in-out infinite;
}
`;

fs.writeFileSync('src/index.css', css);
