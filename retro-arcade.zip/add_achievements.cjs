const fs = require('fs');

const components = ["DonkeyKong.tsx", "Galaga.tsx", "Pacman.tsx", "SpaceInvaders.tsx"];

components.forEach(file => {
  const f = "src/components/" + file;
  let content = fs.readFileSync(f, 'utf8');

  const injection = `
  useEffect(() => {
    if (score >= 1000) {
      window.dispatchEvent(new CustomEvent("achievement", { detail: { id: "score_1000", title: "Arcade Master", text: "1000 Points Reached in " + "${file.replace('.tsx', '')}" + "!" } }));
    }
  }, [score]);

  useEffect(() => {
    if (score >= 5000) {
      window.dispatchEvent(new CustomEvent("achievement", { detail: { id: "score_5000", title: "Retro God", text: "5000 Points Reached in " + "${file.replace('.tsx', '')}" + "!" } }));
    }
  }, [score]);
`;

  const useEffectIndex = content.indexOf('useEffect(() => {');
  if (useEffectIndex !== -1 && !content.includes('score_1000')) {
    content = content.slice(0, useEffectIndex) + injection + content.slice(useEffectIndex);
    fs.writeFileSync(f, content);
  }
});

// For Pong we can use playerSets instead of score, wait, user said "score in any game" - Pong uses playerScore (max 11 per set).
// Let's add it for Pong based on playerScore or just skip since reaching 1000 points in Pong is basically impossible.
