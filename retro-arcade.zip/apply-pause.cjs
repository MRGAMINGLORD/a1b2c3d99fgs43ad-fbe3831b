const fs = require('fs');
const path = require('path');
const dir = path.join(__dirname, 'src', 'components');

const games = ['DonkeyKong.tsx', 'Galaga.tsx', 'Pacman.tsx', 'Pong.tsx'];

games.forEach(file => {
  const f = path.join(dir, file);
  let content = fs.readFileSync(f, 'utf8');

  // UPDATE STATE: replace PAUSED if not exist
  if (!content.includes('"PAUSED"')) {
    content = content.replace(/(useState<.*?)(>)?\("READY"\);/g, (match, prefix, suffix) => {
        if (!prefix.includes('PAUSED')) {
            return prefix + ' | "PAUSED">( "READY" );';
        }
        return match;
    });
  }

  // PREVP + HOOK
  if (!content.includes('const prevP = useRef(false);')) {
    const stateHookMount = 'const canvasWidth ='; // or similar, wait, better to find 'useEffect(() => {' and insert before it
    // Wait, let's just insert before the VERY FIRST useEffect in the game component

    const useEffectIndex = content.indexOf('useEffect(() => {');
    if (useEffectIndex !== -1) {
      const injection = `
  const prevP = useRef(false);

  useEffect(() => {
    if (keyboardState.KeyP && !prevP.current) {
      setGameState(prev => {
        if (prev === "PLAYING") return "PAUSED";
        if (prev === "PAUSED") return "PLAYING";
        return prev;
      });
    }
    prevP.current = keyboardState.KeyP;
  }, [keyboardState.KeyP]);

  `;
      content = content.slice(0, useEffectIndex) + injection + content.slice(useEffectIndex);
    }
  }

  // ADD TO RENDER LOOP TO STOP
  // some use `gameState !== "PLAYING" && gameState !== "DYING"`
  // but if it's already "PAUSED" it will return anyway since it's not PLAYING or DYING. 
  // Wait, so no change needed there!
  
  // ADD JSX SCREEN
  if (!content.includes('gameState === "PAUSED"')) {
     const jsxInjection = `
        {gameState === "PAUSED" && (
          <div className="absolute inset-0 bg-black/50 flex flex-col items-center justify-center text-center p-6 backdrop-blur-[2px]">
            <h4 className="font-mono text-yellow-500 text-4xl tracking-wider animate-pulse font-black">PAUSED</h4>
          </div>
        )}
      </div>`;
     // Usually ends with `</div>` then `{/* Control hints */}` or something
     // Let's replace the last `      </div>` before control hints.
     // If not found, replace the last `</div>\n    </div>`
     const replaceTarget = /<\/div>\s*\{?\/\* Control hints \*\/\*\}?/g;
     if (content.match(replaceTarget)) {
         content = content.replace(replaceTarget, jsxInjection + '\n\n      {/* Control hints */}');
     } else {
         const lastDivs = /<\/div>\s*<\/div>\s*\)\;/g;
         content = content.replace(lastDivs, jsxInjection + '\n    </div>\n  );');
     }
  }

  fs.writeFileSync(f, content);
});
