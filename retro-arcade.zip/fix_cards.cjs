const fs = require('fs');

let f = fs.readFileSync('src/App.tsx', 'utf8');

// For the gamesList map:
f = f.replace(/style=\{isBackCloset \? \{ animationDelay: `\$\{index \* 0.7\}s` \} : \{\}\}/, "style={isBackCloset ? { animationDuration: '10s', animationDelay: `${index * 2}s` } : {}}");

f = f.replace(/<span className=\{`text-2xl \$\{isBackCloset \? 'glitch-text-2' : ''\}`\}>\{g\.icon\}<\/span>/, '<span className="text-2xl">{g.icon}</span>');
f = f.replace(/<h4 className=\{`text-base font-black tracking-wider text-white group-hover:text-yellow-400 transition-colors \$\{isBackCloset \? 'glitch-text-1' : ''\}`\}>/, '<h4 className="text-base font-black tracking-wider text-white group-hover:text-yellow-400 transition-colors">');
f = f.replace(/<p className=\{`text-zinc-400 text-\[10px\] leading-relaxed mt-1 line-clamp-3 \$\{isBackCloset \? 'glitch-text-3' : ''\}`\}>/, '<p className="text-zinc-400 text-[10px] leading-relaxed mt-1 line-clamp-3">');

// For Highscores:
f = f.replace(/<span className=\{`text-zinc-300 font-bold \$\{isBackCloset \? 'glitch-text-1' : ''\}`\}>\{activeScores\[g\.id\]\}<\/span>/, '<span className="text-zinc-300 font-bold">{activeScores[g.id]}</span>');
f = f.replace(/<span className=\{`text-\[10px\] font-bold text-yellow-400 flex items-center gap-1 group-hover:translate-x-1 transition-transform \$\{isBackCloset \? 'glitch-text-2' : ''\}`\}>/, '<span className="text-[10px] font-bold text-yellow-400 flex items-center gap-1 group-hover:translate-x-1 transition-transform">');

fs.writeFileSync('src/App.tsx', f);
