const fs = require('fs');

const f = 'src/components/Pacman.tsx';
let content = fs.readFileSync(f, 'utf8');

// Replace P with O in MAZE_MAP
content = content.replace(/"WDDDDDDDWWOOOPOOOOWWDDDDDDDW",/g, '"WDDDDDDDWWOOOOOOOOOWWDDDDDDDW",');

// Replace pacmanRef initialization
content = content.replace(/x: 9, y: 16,/g, 'x: 13, y: 22,');

// Replace ghostsRef initialization
content = content.replace(/x: 9, y: 10,/g, 'x: 13, y: 14,');
content = content.replace(/x: 8, y: 10,/g, 'x: 14, y: 14,');
content = content.replace(/x: 10, y: 10,/g, 'x: 12, y: 14,');
content = content.replace(/x: 9, y: 9,/g, 'x: 15, y: 14,');

// Replace hardcoded respawn positions (just in case they were different)
content = content.replace(/ghost.x = 13;\s*ghost.y = 14;/g, 'ghost.x = 13;\n            ghost.y = 14;');

// Find resetPacman function if it exists and change its x and y
content = content.replace(/pac.x = 9;\s*pac.y = 16;/g, 'pac.x = 13;\n      pac.y = 22;');

// Update ghosts resetting explicitly
content = content.replace(/g.x = 9;\s*g.y = 10;/g, 'g.x = 13;\n        g.y = 14;');
content = content.replace(/g.x = 8;\s*g.y = 10;/g, 'g.x = 14;\n        g.y = 14;');

fs.writeFileSync(f, content);
