const fs = require('fs');

let code = fs.readFileSync('src/components/DonkeyKong.tsx', 'utf8');

// I need to strip the duplicated getPlatformY and ladders declarations
// Let's just remove the first batch up to where the original ones were so it looks clean
// Wait, I replaced platforms with `platformsReplacement` which had it all. So now I have TWO getPlatformY's and TWO ladders.
// Let's just delete the second ones!

const pattern = /\/\/ Ladders connecting the layers[\s\S]*?\/\/ Pauline ladder\s*\}\s*\,?\s*\];/g;
const matches = [...code.matchAll(pattern)];

if (matches.length > 1) {
  // We matched multiple ladders. 
  // Let's find the `const getPlatformY` also.
  const getPlatMatch = [...code.matchAll(/const getPlatformY = [\s\S]*?return plat.yStart \+ t \* \(plat.yEnd \- plat.yStart\);\s*\};/g)];
  if (getPlatMatch.length > 1) {
     // replace the second occurrence with empty string
     code = code.substring(0, getPlatMatch[1].index) + code.substring(getPlatMatch[1].index + getPlatMatch[1][0].length);
  }
  
  const ladderMatch = [...code.matchAll(/const ladders: Ladder\[\] = [\s\S]*?Pauline ladder\s*\}\s*\,?\s*\];/g)];
  if (ladderMatch.length > 1) {
     code = code.substring(0, ladderMatch[1].index) + code.substring(ladderMatch[1].index + ladderMatch[1][0].length);
  }
}

fs.writeFileSync('src/components/DonkeyKong.tsx', code);
