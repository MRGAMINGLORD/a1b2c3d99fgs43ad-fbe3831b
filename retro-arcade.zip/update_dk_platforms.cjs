const fs = require('fs');
let code = fs.readFileSync('src/components/DonkeyKong.tsx', 'utf8');

const platformsReplacement = `  ] : [
    { yStart: 120, yEnd: 120, xStart: 100, xEnd: 500 },  // Top platform (Flat)
    { yStart: 200, yEnd: 180, xStart: 0,  xEnd: 500 },  // Middle 1 (Right is up)
    { yStart: 260, yEnd: 280, xStart: 100,  xEnd: 600 },  // Middle 2 (Left is up)
    { yStart: 360, yEnd: 340, xStart: 0,  xEnd: 550 },  // Bottom platform (Right is up)
  ];`;

code = code.replace(/\] : \[\s*\{ yStart: 120, yEnd: 120, xStart: 100, xEnd: 460 \},\s*\/\/ Top platform \(Flat\)\s*\{ yStart: 200, yEnd: 180, xStart: 50,\s*xEnd: 500 \},\s*\/\/ Middle 1 \(Right is up\)\s*\{ yStart: 260, yEnd: 280, xStart: 20,\s*xEnd: 460 \},\s*\/\/ Middle 2 \(Left is up\)\s*\{ yStart: 360, yEnd: 340, xStart: 50,\s*xEnd: 520 \},\s*\/\/ Bottom platform \(Right is up\)\s*\];/m, platformsReplacement);

const laddersReplacement = `  ] : [
    { x: 440, yBottom: getPlatformY(platforms[3], 440), yTop: getPlatformY(platforms[2], 440) }, // 3 -> 2
    { x: 380, yBottom: getPlatformY(platforms[3], 380), yTop: getPlatformY(platforms[2], 380) }, // Extra 3 -> 2
    { x: 250, yTop: getPlatformY(platforms[2], 250), yBottom: getPlatformY(platforms[2], 250) + 25, isBroken: true },
    { x: 250, yTop: getPlatformY(platforms[3], 250) - 25, yBottom: getPlatformY(platforms[3], 250), isBroken: true },

    { x: 120, yBottom: getPlatformY(platforms[2], 120), yTop: getPlatformY(platforms[1], 120) }, // 2 -> 1
    { x: 240, yBottom: getPlatformY(platforms[2], 240), yTop: getPlatformY(platforms[1], 240) }, // Extra 2 -> 1
    { x: 380, yTop: getPlatformY(platforms[1], 380), yBottom: getPlatformY(platforms[1], 380) + 25, isBroken: true },
    { x: 380, yTop: getPlatformY(platforms[2], 380) - 25, yBottom: getPlatformY(platforms[2], 380), isBroken: true },

    { x: 440, yBottom: getPlatformY(platforms[1], 440), yTop: getPlatformY(platforms[0], 440) }, // 1 -> 0
    { x: 350, yBottom: getPlatformY(platforms[1], 350), yTop: getPlatformY(platforms[0], 350) }, // Extra 1 -> 0
    
    { x: 180, yTop: getPlatformY(platforms[0], 180), yBottom: getPlatformY(platforms[0], 180) + 25, isBroken: true },
    { x: 180, yTop: getPlatformY(platforms[1], 180) - 25, yBottom: getPlatformY(platforms[1], 180), isBroken: true },

    { x: 300, yBottom: 120, yTop: 60 },  // Pauline ladder
  ];`;

code = code.replace(/\] : \[[\s\S]*?Pauline ladder\s*\}\,?\s*\];/m, laddersReplacement);

fs.writeFileSync('src/components/DonkeyKong.tsx', code);
