const fs = require('fs');

// Space Invaders
let si = fs.readFileSync('src/components/SpaceInvaders.tsx', 'utf8');
si = si.replace(/const baseSpeed = 0.5 \+ \(stateRef.current.level \* 0.2\);/g, 
  'const diffM = difficulty === "HARD" ? 1.5 : (difficulty === "EASY" ? 0.6 : 1);\n      const baseSpeed = (0.5 + (stateRef.current.level * 0.2)) * diffM;');
si = si.replace(/const maxEnemyBullets = Math.min\(8, 3 \+ state.level\);/g, 
  'const maxEnemyBullets = Math.min(8, 3 + state.level) * (difficulty === "HARD" ? 1.5 : (difficulty === "EASY" ? 0.5 : 1));');
si = si.replace(/const fireProb = Math.min\(0.04, 0.015 \+ \(state.level \* 0.003\)\);/g, 
  'const fireProb = Math.min(0.04, 0.015 + (state.level * 0.003)) * (difficulty === "HARD" ? 1.5 : (difficulty === "EASY" ? 0.5 : 1));');
fs.writeFileSync('src/components/SpaceInvaders.tsx', si);

// Galaga
let ga = fs.readFileSync('src/components/Galaga.tsx', 'utf8');
ga = ga.replace(/state.diveTimer = 140 - Math.min\(80, score \/ 20\);/g, 
  'const diffM = difficulty === "HARD" ? 0.6 : (difficulty === "EASY" ? 1.5 : 1);\n            state.diveTimer = (140 - Math.min(80, score / 20)) * diffM;');
ga = ga.replace(/if \(!isChallengeStage && Math.random\(\) < 0.012 && en.y < canvasHeight - 120\)/g, 
  'const fireProb = 0.012 * (difficulty === "HARD" ? 2 : (difficulty === "EASY" ? 0.5 : 1));\n          if (!isChallengeStage && Math.random() < fireProb && en.y < canvasHeight - 120)');
fs.writeFileSync('src/components/Galaga.tsx', ga);

// Pacman
let pa = fs.readFileSync('src/components/Pacman.tsx', 'utf8');
pa = pa.replace(/const ghostSpeed = 1.5 \+ \(isNextLevel \? level \* 0.1 : 0\);/g, 
  'const diffM = difficulty === "HARD" ? 1.3 : (difficulty === "EASY" ? 0.7 : 1);\n    const ghostSpeed = (1.5 + (isNextLevel ? level * 0.1 : 0)) * diffM;');
pa = pa.replace(/speed: 1.5, color: "#ff0000"/g, 'speed: ghostSpeed, color: "#ff0000"');
pa = pa.replace(/speed: 1.5, color: "#ffb8ff"/g, 'speed: ghostSpeed, color: "#ffb8ff"');
pa = pa.replace(/speed: 1.5, color: "#00ffff"/g, 'speed: ghostSpeed, color: "#00ffff"');
pa = pa.replace(/speed: 1.5, color: "#ffb852"/g, 'speed: ghostSpeed, color: "#ffb852"');
pa = pa.replace(/if \(!stateRef.current.activePowerMode\) \{\s*let targetTimer = 600;/g, 'if (!stateRef.current.activePowerMode) {\n        let targetTimer = difficulty === "HARD" ? 900 : (difficulty === "EASY" ? 400 : 600);');
fs.writeFileSync('src/components/Pacman.tsx', pa);

// Donkey Kong
let dk = fs.readFileSync('src/components/DonkeyKong.tsx', 'utf8');
dk = dk.replace(/state.barrelTimer = Math.max\(20, 60 - \(level \* 5\)\);/g, 
  'const diffM = difficulty === "HARD" ? 0.6 : (difficulty === "EASY" ? 1.5 : 1);\n    state.barrelTimer = Math.max(20, (60 - (level * 5)) * diffM);');
fs.writeFileSync('src/components/DonkeyKong.tsx', dk);

// Pong
let po = fs.readFileSync('src/components/Pong.tsx', 'utf8');
// Base AI speed is 4
po = po.replace(/const aiSpeed = /g, 'const diffM = difficulty === "HARD" ? 1.5 : (difficulty === "EASY" ? 0.5 : 1);\n      const aiSpeedBase = ');
po = po.replace(/const aiSpeedBase = 4 \+ \(\(aiScore \+ playerSets \* 2\) \* 0\.5\);/g, 'const aiSpeed = (4 + ((aiScore + playerSets * 2) * 0.5)) * diffM;');
fs.writeFileSync('src/components/Pong.tsx', po);

