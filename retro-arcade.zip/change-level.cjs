const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, 'src', 'components');
const games = ['DonkeyKong.tsx', 'Galaga.tsx', 'Pacman.tsx', 'SpaceInvaders.tsx'];

games.forEach(file => {
  const f = path.join(dir, file);
  let content = fs.readFileSync(f, 'utf8');

  content = content.replace(/useState\(1\)/g, 'useState(2)');
  content = content.replace(/setLevel\(1\)/g, 'setLevel(2)');
  content = content.replace(/level: 1,/g, 'level: 2,');

  fs.writeFileSync(f, content);
});
