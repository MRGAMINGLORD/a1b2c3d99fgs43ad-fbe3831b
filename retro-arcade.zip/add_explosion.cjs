const fs = require('fs');

const components = ["DonkeyKong.tsx", "Galaga.tsx", "Pacman.tsx", "Pong.tsx", "SpaceInvaders.tsx"];

components.forEach(file => {
  const f = "src/components/" + file;
  let content = fs.readFileSync(f, 'utf8');

  if (!content.includes('ParticleExplosion')) {
      content = content.replace(/import React, \{ useEffect, useRef, useState \} from "react";/, 'import React, { useEffect, useRef, useState } from "react";\nimport { ParticleExplosion } from "./ParticleExplosion";');
      
      const parts = content.split('gameState === "GAMEOVER" && (');
      if (parts.length > 1) {
          content = parts[0] + 'gameState === "GAMEOVER" && (' + parts[1].replace(/<div className="absolute inset-0 bg-black\/90 flex flex-col items-center justify-center text-center p-6">/, '<div className="absolute inset-0 bg-black/90 flex flex-col items-center justify-center text-center p-6">\n            <ParticleExplosion color="#ef4444" />');
      }
      fs.writeFileSync(f, content);
  }
});
