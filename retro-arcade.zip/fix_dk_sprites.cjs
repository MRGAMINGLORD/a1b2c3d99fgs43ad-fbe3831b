const fs = require('fs');

let code = fs.readFileSync('src/components/DonkeyKong.tsx', 'utf8');

// Fix DK Sprite body
code = code.replace(
  /"DDDDD\.\.\.\.\.\.\.DDDDD",\n\s*"DDDDD\.\.\.\.\.\.\.DDDDD",\n\s*"DDDDD\.\.\.\.\.\.\.DDDDD",\n\s*"DDDDD\.\.\.\.\.\.\.DDDDD",\n\s*"DDDDD\.\.\.\.\.\.\.DDDDD"/g,
  '"DDDDD.DDDDD.DDDDD",\n    "DDDDD.DDDDD.DDDDD",\n    "DDDDD.DDDDD.DDDDD",\n    "DDDDD.DDDDD.DDDDD",\n    "DDDDD.DDDDD.DDDDD"'
);

// We need to fix Stomp too
code = code.replace(
  /"DDDD\.\.\.\.\.\.\.\.\.DDDD",\n\s*"DD\.\.\.DD\.\.\.DD\.\.\.DD",\n\s*"D\.\.\.DDD\.\.\.DDD\.\.\.D",\n\s*"\.\.\.DDDD\.\.\.DDDD\.\.\."/g,
  '"DDDD.DDDDDDD.DDDD",\n    "DDDD.DDDDDDD.DDDD",\n    "DD...DDDDDDD...DD",\n    "...DDDDDDDDD..."'
);

code = code.replace(
  /"DDDD\.\.\.\.\.\.\.\.\.DDDD",\n\s*"DD...DD\.\.\.DD\.\.\.DD",\n\s*"D...DDD\.\.\.DDD\.\.\.D",\n\s*"\.\.\.DDDD\.\.\.DDDD\.\.\."/g,
  '"DDDD.DDDDDDD.DDDD",\n    "DDDD.DDDDDDD.DDDD",\n    "DD...DDDDDDD...DD",\n    "...DDDDDDDDD..."'
);

code = code.replace(
  /"DDDD\.\.\.\.\.\.\.\.\.DDDD",\n\s*"DD\.\.\.DD\.\.\.DD\.\.\.DD",/g,
  '"DDDD.DDDDDDD.DDDD",\n    "DD...DDDDDDD...DD",'
);


// scale up player
code = code.replace(/const playerWidth = 12;/g, 'const playerWidth = 24;');
code = code.replace(/const playerHeight = 16;/g, 'const playerHeight = 32;');

// When drawing player with scale 1, we change to scale 2
code = code.replace(/drawSprite\(ctx, SPRITES.dkStand, state\.playerX \+ wiggleX, state\.playerY \+ fallOffset, 1\);/g, 'drawSprite(ctx, SPRITES.dkStand, state.playerX + wiggleX, state.playerY + fallOffset, 2);');
code = code.replace(/drawSprite\(ctx, SPRITES.marioStand, -6, -8, 1\);/g, 'drawSprite(ctx, SPRITES.marioStand, -12, -16, 2);');
code = code.replace(/drawSprite\(ctx, SPRITES.dkStand, state.playerX, state.playerY, 1, flip\);/g, 'drawSprite(ctx, SPRITES.dkStand, state.playerX, state.playerY, 2, flip);');
code = code.replace(/drawSprite\(ctx, sprite, state.playerX, state.playerY, 1\);/g, 'drawSprite(ctx, sprite, state.playerX, state.playerY, 2);');
code = code.replace(/drawSprite\(ctx, sprite, state.playerX, state.playerY, 1, state.playerVx < 0\);/g, 'drawSprite(ctx, sprite, state.playerX, state.playerY, 2, state.playerVx < 0);');

// Make barrels larger
code = code.replace(/size: 16/g, 'size: 24');
code = code.replace(/drawSprite\(ctx, frame === 0 \? SPRITES.barrel1 : SPRITES.barrel2, bar.x - bar.size\/2, bar.y, 1\);/g, 'drawSprite(ctx, frame === 0 ? SPRITES.barrel1 : SPRITES.barrel2, bar.x - bar.size/2, bar.y, 1.5);');

fs.writeFileSync('src/components/DonkeyKong.tsx', code);
