const fs = require('fs');

const components = ["DonkeyKong.tsx", "Galaga.tsx", "Pacman.tsx", "Pong.tsx", "SpaceInvaders.tsx"];

components.forEach(file => {
  const f = "src/components/" + file;
  let content = fs.readFileSync(f, 'utf8');
  content = content.replace(/import \{ KeyboardState \} from "\.\.\/types";/g, 'import { KeyboardState, Difficulty } from "../types";');
  content = content.replace(/isBackCloset\?: boolean;/g, 'isBackCloset?: boolean;\n  difficulty?: Difficulty;');
  content = content.replace(/isBackCloset = false \}: GameProps\)/g, 'isBackCloset = false, difficulty = "MEDIUM" }: GameProps)');
  fs.writeFileSync(f, content);
});
