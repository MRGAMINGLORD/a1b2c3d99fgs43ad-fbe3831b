const fs = require('fs');

let f = fs.readFileSync('src/App.tsx', 'utf8');

f = f.replace(/<div className=\{`p-3 bg-black\/40 border border-zinc-800 rounded-lg flex items-center justify-between \$\{isBackCloset \? 'glitch-card' : ''\}`\}>/g, function(match, offset) {
   // Generate an index sequence
   if (!this.count) this.count = 0;
   const idx = this.count++;
   return `<div className={\`p-3 bg-black/40 border border-zinc-800 rounded-lg flex items-center justify-between \${isBackCloset ? 'glitch-card' : ''}\`} style={isBackCloset ? { animationDuration: '10s', animationDelay: \`\${idx * 2}s\` } : {}}>`;
});

// Also remove internal glitch-text classes inside HIGH SCORE DASHBOARD
f = f.replace(/<span className=\{`text-\[10px\] text-zinc-500 block \$\{isBackCloset \? 'glitch-text-[123]' : ''\}`\}>/g, '<span className="text-[10px] text-zinc-500 block">');
f = f.replace(/<span className=\{`text-sm(.*?)\$\{isBackCloset \? 'glitch-text-[123]' : ''\}`\}>/g, '<span className={`text-sm$1`}>');
f = f.replace(/<span className=\{`text-base text-zinc-200 font-black \$\{isBackCloset \? 'glitch-text-[123]' : ''\}`\}>/g, '<span className="text-base text-zinc-200 font-black">');

// One more check in App.tsx: The text-sm for the game titles was text-sm text-[color]-400 font-bold...
// let's do a more robust sweep for 'glitch-text' in the highscore dash:
f = f.replace(/`text-sm text-green-400 font-bold \$\{isBackCloset \? 'glitch-text-1' : ''\}`/g, '"text-sm text-green-400 font-bold"');
f = f.replace(/`text-sm text-yellow-400 font-bold \$\{isBackCloset \? 'glitch-text-2' : ''\}`/g, '"text-sm text-yellow-400 font-bold"');
f = f.replace(/`text-sm text-pink-400 font-bold \$\{isBackCloset \? 'glitch-text-3' : ''\}`/g, '"text-sm text-pink-400 font-bold"');
f = f.replace(/`text-sm text-blue-400 font-bold \$\{isBackCloset \? 'glitch-text-1' : ''\}`/g, '"text-sm text-blue-400 font-bold"');
f = f.replace(/`text-sm text-emerald-400 font-bold \$\{isBackCloset \? 'glitch-text-2' : ''\}`/g, '"text-sm text-emerald-400 font-bold"');

fs.writeFileSync('src/App.tsx', f);
