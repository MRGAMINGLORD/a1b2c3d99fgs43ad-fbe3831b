const fs = require('fs');

const components = ["DonkeyKong.tsx", "Galaga.tsx", "Pacman.tsx", "Pong.tsx", "SpaceInvaders.tsx"];

components.forEach(file => {
  const f = "src/components/" + file;
  let content = fs.readFileSync(f, 'utf8');

  // Replace <canvas ...></canvas> with <canvas ...></canvas> + glow div
  // But canvas might be self-closing or not.
  // Actually, I can just replace `</canvas>` with `</canvas>\n        {/* CRT Glow */}\n        <div className="absolute inset-0 pointer-events-none shadow-[inset_0_0_30px_rgba(255,255,255,0.1),inset_0_0_50px_rgba(0,0,0,0.5),0_0_15px_rgba(255,255,255,0.1)] mix-blend-screen rounded select-none"></div>`
  
  if (content.includes('</canvas>')) {
     if (!content.includes('CRT Glow')) {
        content = content.replace(/<\/canvas>/g, '</canvas>\n        {/* CRT Glow */}\n        <div className="absolute inset-0 pointer-events-none shadow-[inset_0_0_20px_rgba(255,255,255,0.05),inset_0_0_30px_rgba(0,0,0,0.5),0_0_20px_rgba(255,255,255,0.1)] mix-blend-screen rounded-sm opacity-80 select-none bg-[radial-gradient(ellipse_at_center,_transparent_50%,_rgba(0,0,0,0.15)_100%)]"></div>');
     }
  } else {
     // Self closing 
     if (!content.includes('CRT Glow')) {
        content = content.replace(/(<canvas[^>]*?\/>)/g, '$1\n        {/* CRT Glow */}\n        <div className="absolute inset-0 pointer-events-none shadow-[inset_0_0_20px_rgba(255,255,255,0.05),inset_0_0_30px_rgba(0,0,0,0.5),0_0_20px_rgba(255,255,255,0.1)] mix-blend-screen rounded-sm opacity-80 select-none bg-[radial-gradient(ellipse_at_center,_transparent_50%,_rgba(0,0,0,0.15)_100%)]"></div>');
     }
  }
  
  fs.writeFileSync(f, content);
});
