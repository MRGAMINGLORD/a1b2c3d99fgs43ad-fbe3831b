const fs = require('fs');
const path = require('path');
const dir = path.join(__dirname, 'src', 'components');
fs.readdirSync(dir).forEach(file => {
  if (file.endsWith('.tsx')) {
    const f = path.join(dir, file);
    let content = fs.readFileSync(f, 'utf8');
    content = content.replace(/onClick=\{startGame\}/g, 'onClick={() => startGame()}');
    fs.writeFileSync(f, content);
  }
});
