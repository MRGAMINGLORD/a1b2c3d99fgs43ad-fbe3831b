const fs = require('fs');

let appCode = fs.readFileSync('src/App.tsx', 'utf8');

appCode = appCode.replace(/<span className=\{\`text-sm text-green-400 font-bold \`\}>1972 VERSION<\/span>/g, '');
appCode = appCode.replace(/<span className=\{\`text-sm text-yellow-400 font-bold \`\}>GOBBLER MAZE<\/span>/g, '');
appCode = appCode.replace(/<span className=\{\`text-sm text-pink-400 font-bold \`\}>GIRDER CLIMB<\/span>/g, '');
appCode = appCode.replace(/<span className=\{\`text-sm text-blue-400 font-bold \`\}>STAR FIGHTER<\/span>/g, '');
appCode = appCode.replace(/<span className=\{\`text-sm text-emerald-400 font-bold \`\}>SPACE SHIELD<\/span>/g, '');

fs.writeFileSync('src/App.tsx', appCode);
