const fs = require('fs');

['Pong', 'Pacman', 'DonkeyKong', 'SpaceInvaders', 'Galaga'].forEach(game => {
    let code = fs.readFileSync(`src/components/${game}.tsx`, 'utf8');
    if (game === 'Pong') {
      code = code.replace(/PADDLE COMMAND \(PONG\)/g, 'PONG');
      code = code.replace(/PADDLE DEMON \(PONG: NIGHTMARE\)/g, 'PONG');
    }
    if (game === 'Pacman') {
      code = code.replace(/GOBBLER MAZE \(PAC-MAN\)/g, 'PAC-MAN');
      code = code.replace(/MAZE DEMON \(NIGHTMARE\)/g, 'PAC-MAN');
    }
    if (game === 'DonkeyKong') {
      code = code.replace(/GIRDER CLIMB \(DONKEY KONG\)/g, 'DONKEY KONG');
      code = code.replace(/VINE CLIMB \(DONKEY KONG JR\)/g, 'DONKEY KONG');
    }
    if (game === 'SpaceInvaders') {
      code = code.replace(/RETRO INVADERS \(SPACE INVADERS\)/g, 'SPACE INVADERS');
      code = code.replace(/COSMIC HORROR \(NIGHTMARE\)/g, 'SPACE INVADERS');
    }
    if (game === 'Galaga') {
      code = code.replace(/STAR FIGHTER \(GALAGA\)/g, 'GALAGA');
      code = code.replace(/VOID FLEET \(NIGHTMARE\)/g, 'GALAGA');
    }
    fs.writeFileSync(`src/components/${game}.tsx`, code);
});
