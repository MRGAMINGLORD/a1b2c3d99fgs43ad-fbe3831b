const fs = require('fs');

let code = fs.readFileSync('src/components/DonkeyKong.tsx', 'utf8');

code = code.replace(/currentPlatformIndex: 0,\s*size: 16/g, "currentPlatformIndex: isBackCloset ? -1 : -1,\n              size: 16");

fs.writeFileSync('src/components/DonkeyKong.tsx', code);
