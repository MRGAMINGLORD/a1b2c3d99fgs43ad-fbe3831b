const fs = require('fs');

let code = fs.readFileSync('src/components/DonkeyKong.tsx', 'utf8');

const platformsReplacement = `  ] : [
    { yStart: 120, yEnd: 120, xStart: 100, xEnd: 460 },  // Top platform (Flat)
    { yStart: 200, yEnd: 180, xStart: 50,  xEnd: 500 },  // Middle 1 (Right is up)
    { yStart: 260, yEnd: 280, xStart: 20,  xEnd: 460 },  // Middle 2 (Left is up)
    { yStart: 360, yEnd: 340, xStart: 50,  xEnd: 520 },  // Bottom platform (Right is up)
  ];

  const getPlatformY = (plat: Platform, x: number) => {
    if (x < plat.xStart) return plat.yStart;
    if (x > plat.xEnd) return plat.yEnd;
    const t = (x - plat.xStart) / (plat.xEnd - plat.xStart);
    return plat.yStart + t * (plat.yEnd - plat.yStart);
  };

  // Ladders connecting the layers
  const ladders: Ladder[] = isBackCloset ? [
    { x: 150, yTop: 240, yBottom: 380 }, // Mid-left to ground
    { x: 380, yTop: 180, yBottom: 300 }, // Up-Right to Mid-Right
    { x: 450, yTop: 180, yBottom: 380 }, // Up-Right to ground
    { x: 100, yTop: 240, yBottom: 360 }, // Mid-Left to Lower-Left
    { x: 230, yTop: 120, yBottom: 240 },  // Top to Mid-Left
    { x: 340, yTop: 120, yBottom: 180 },  // Top to Upper-Right
    { x: 280, yTop: 60, yBottom: 120 },    // Top to DK
    { x: 320, yTop: 60, yBottom: 120 },    // Top to DK
  ] : [
    { x: 440, yBottom: getPlatformY({ yStart: 360, yEnd: 340, xStart: 50,  xEnd: 520 }, 440), yTop: getPlatformY({ yStart: 260, yEnd: 280, xStart: 20,  xEnd: 460 }, 440) }, // 3 -> 2
    { x: 380, yBottom: getPlatformY({ yStart: 360, yEnd: 340, xStart: 50,  xEnd: 520 }, 380), yTop: getPlatformY({ yStart: 260, yEnd: 280, xStart: 20,  xEnd: 460 }, 380) }, // Extra 3 -> 2
    { x: 250, yTop: getPlatformY({ yStart: 260, yEnd: 280, xStart: 20,  xEnd: 460 }, 250), yBottom: getPlatformY({ yStart: 260, yEnd: 280, xStart: 20,  xEnd: 460 }, 250) + 25, isBroken: true },
    { x: 250, yTop: getPlatformY({ yStart: 360, yEnd: 340, xStart: 50,  xEnd: 520 }, 250) - 25, yBottom: getPlatformY({ yStart: 360, yEnd: 340, xStart: 50,  xEnd: 520 }, 250), isBroken: true },

    { x: 120, yBottom: getPlatformY({ yStart: 260, yEnd: 280, xStart: 20,  xEnd: 460 }, 120), yTop: getPlatformY({ yStart: 200, yEnd: 180, xStart: 50,  xEnd: 500 }, 120) }, // 2 -> 1
    { x: 240, yBottom: getPlatformY({ yStart: 260, yEnd: 280, xStart: 20,  xEnd: 460 }, 240), yTop: getPlatformY({ yStart: 200, yEnd: 180, xStart: 50,  xEnd: 500 }, 240) }, // Extra 2 -> 1
    { x: 380, yTop: getPlatformY({ yStart: 200, yEnd: 180, xStart: 50,  xEnd: 500 }, 380), yBottom: getPlatformY({ yStart: 200, yEnd: 180, xStart: 50,  xEnd: 500 }, 380) + 25, isBroken: true },
    { x: 380, yTop: getPlatformY({ yStart: 260, yEnd: 280, xStart: 20,  xEnd: 460 }, 380) - 25, yBottom: getPlatformY({ yStart: 260, yEnd: 280, xStart: 20,  xEnd: 460 }, 380), isBroken: true },

    { x: 440, yBottom: getPlatformY({ yStart: 200, yEnd: 180, xStart: 50,  xEnd: 500 }, 440), yTop: getPlatformY({ yStart: 120, yEnd: 120, xStart: 100, xEnd: 460 }, 440) }, // 1 -> 0
    { x: 350, yBottom: getPlatformY({ yStart: 200, yEnd: 180, xStart: 50,  xEnd: 500 }, 350), yTop: getPlatformY({ yStart: 120, yEnd: 120, xStart: 100, xEnd: 460 }, 350) }, // Extra 1 -> 0
    
    { x: 180, yTop: getPlatformY({ yStart: 120, yEnd: 120, xStart: 100, xEnd: 460 }, 180), yBottom: getPlatformY({ yStart: 120, yEnd: 120, xStart: 100, xEnd: 460 }, 180) + 25, isBroken: true },
    { x: 180, yTop: getPlatformY({ yStart: 200, yEnd: 180, xStart: 50,  xEnd: 500 }, 180) - 25, yBottom: getPlatformY({ yStart: 200, yEnd: 180, xStart: 50,  xEnd: 500 }, 180), isBroken: true },

    { x: 300, yBottom: 120, yTop: 60 },  // Pauline ladder
  ];`;

code = code.replace(/\] : \[\s*\{ yStart: 120, yEnd: 120, xStart: 120, xEnd: 550 \},[\s\S]*?\];/m, platformsReplacement);

const barrelUpdateCode = `      // 4. Update barrels
      state.barrels.forEach((bar, idx) => {
        if (bar.falling) {
          bar.y += 3;
          // Land on platform below
          let landed = false;
          // We check the platform it's supposed to fall to, which is currentPlatformIndex + 1
          const nextPlatIndex = bar.currentPlatformIndex + 1;
          const plat = platforms[nextPlatIndex];
          if (plat) {
            if (bar.x >= plat.xStart && bar.x <= plat.xEnd) {
              const platY = getPlatformY(plat, bar.x);
              if (bar.y + bar.size >= platY - 4 && bar.y + bar.size - 5 <= platY + 6) {
                bar.y = platY - bar.size;
                bar.currentPlatformIndex = nextPlatIndex;
                bar.falling = false;
                landed = true;
                
                // Roll direction based on slope or layer
                if (plat.yEnd > plat.yStart) {
                   bar.vx = 2.2; // rolls right (downhill)
                } else if (plat.yEnd < plat.yStart) {
                   bar.vx = -2.2; // rolls left (downhill)
                } else {
                   // Flat platform
                   bar.vx = nextPlatIndex % 2 === 0 ? 2.2 : -2.2; 
                }
              }
            }
          }
          // Bottom pit delete
          if (bar.y > canvasHeight - 15) {
            landed = true;
          }
        } else {
          bar.x += bar.vx;

          // Check if it rolled off edge
          const plat = platforms[bar.currentPlatformIndex];
          if (plat && (bar.x < plat.xStart || bar.x > plat.xEnd)) {
            bar.falling = true;
            bar.vx = bar.vx > 0 ? 0.3 : -0.3; // Give it slight forward momentum, but mostly fall straight down
          } else if (plat) {
             // Snap to slope
             bar.y = getPlatformY(plat, bar.x) - bar.size;
          }

          // Randomly roll down ladder with some probability
          ladders.forEach((ladder) => {
            if (Math.abs(bar.x - ladder.x) < 4 && Math.abs(bar.y + bar.size - ladder.yTop) < 4) {
              if (!ladder.isBroken && Math.random() < (isBackCloset ? 0.8 : 0.25) && ladder.yBottom !== 60) {
                bar.vx = 0;
                bar.falling = true;
                bar.y += 5; // offset slightly down to fall
              }
            }
          });
        }

        // Barrel and Jumpman collision checking
        const bDistX = Math.abs((state.playerX + playerWidth / 2) - bar.x);
        const bDistY = Math.abs((state.playerY + playerHeight / 2) - (bar.y + bar.size / 2));

        if (bDistX < 14 && bDistY < 14 && gameState !== "DYING") {`;

code = code.replace(/\/\/ 4\. Update barrels[\s\S]*?if \(bDistX < 14 && bDistY < 14 && gameState !== "DYING"\) \{/m, barrelUpdateCode);

fs.writeFileSync('src/components/DonkeyKong.tsx', code);
