const fs = require('fs');

let appCode = fs.readFileSync('src/App.tsx', 'utf8');

// Add scanlines state
appCode = appCode.replace(/const \[isMuted, setIsMuted\] = useState\(false\);/, 'const [isMuted, setIsMuted] = useState(false);\n  const [scanlineEnabled, setScanlineEnabled] = useState(true);');

// Add button for scanlines inside diagnostics
const diagnosticsHTML = `<button 
            onClick={() => setScanlineEnabled(!scanlineEnabled)} 
            className="p-1 hover:bg-zinc-800 rounded transition duration-200 cursor-pointer flex items-center gap-1"
          >
            <span className={\`text-[10px] hidden sm:inline \${scanlineEnabled ? "text-blue-400" : "text-zinc-500"}\`}>CRT: {scanlineEnabled ? 'ON' : 'OFF'}</span>
          </button>`;

appCode = appCode.replace(/(<button[\s\S]*?id="global-mute-btn"[\s\S]*?<\/button>)/, `$1\n          ${diagnosticsHTML}`);

// Modify scanlines div to use the state
appCode = appCode.replace(
  /<div className="absolute inset-0 pointer-events-none bg-scanlines opacity-\[0.07\] z-10"><\/div>/g,
  '{scanlineEnabled && <div className="absolute inset-0 pointer-events-none bg-scanlines opacity-[0.07] z-10"></div>}'
);

// Add animate-arcade-glow to the main ARCADE CABINET wrapper
appCode = appCode.replace(
    /className=\{\`w-full relative rounded-3xl border-\[8px\] overflow-hidden flex flex-col \$\{theme\.bgDark\} \$\{theme\.border\} \$\{theme\.cabShadow\} \$\{isBackCloset \? 'glitch-container' : ''\}\`\}/g,
    "className={`w-full relative animate-arcade-glow rounded-3xl border-[8px] overflow-hidden flex flex-col ${theme.bgDark} ${theme.border} ${theme.cabShadow} ${isBackCloset ? 'glitch-container' : ''}`}"
);

fs.writeFileSync('src/App.tsx', appCode);
