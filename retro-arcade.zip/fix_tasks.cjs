const fs = require('fs');

// --- server.ts ---
let serverCode = fs.readFileSync('server.ts', 'utf8');
serverCode = serverCode.replace(
  /prompt = `You are a retro arcade assistant named Waffle AI living inside a haunted arcade cabinet\. You speak in cryptic riddles\./g,
  "prompt = `You are a retro arcade assistant named Waffle AI. Give real, useful, tactical gameplay tips to help the player succeed at classic arcade games, but maintain a slightly mysterious haunted vibe."
);
serverCode = serverCode.replace(
  /prompt = `You are a retro arcade assistant named Waffle AI living inside a haunted arcade cabinet\. Give a very short, cryptic 1-2 sentence tip or trick for the arcade game \${game}\./g,
  "prompt = `You are a retro arcade assistant named Waffle AI. Give a real, very useful, specific 1-2 sentence tactical gameplay trick for the arcade game ${game}."
);
fs.writeFileSync('server.ts', serverCode);

// --- App.tsx ---
let appCode = fs.readFileSync('src/App.tsx', 'utf8');

// padding adjustments for bezel
appCode = appCode.replace(
  /className=\{`p-4 sm:p-8 md:p-12 \$\{theme\.bgMedium\} flex justify-center`\}/g,
  "className={`p-2 sm:p-4 md:p-6 ${theme.bgMedium} flex justify-center`}"
);

// achievement styling for back closet
appCode = appCode.replace(
  /className=\{`font-bold tracking-wider mb-1 \$\{unlocked \? 'text-yellow-400' : 'text-zinc-600'\}`\}\>\{ach\.title\}\<\/h4\>/g,
  "className={`font-bold tracking-wider mb-1 ${unlocked ? 'text-yellow-400' : 'text-zinc-600'} ${ach.id === 'back_closet' ? 'glitch-jitter bg-clip-text text-transparent bg-gradient-to-r from-red-600 via-purple-500 to-red-600 drop-shadow-[0_0_10px_rgba(255,0,0,0.8)]' : ''}`}>{ach.id === 'back_closet' ? 'T H E   B A C K   C L O S E T' : ach.title}</h4>"
);

// leave back closet button in App.tsx
// wait, where should the button go? 
// Probably near the "RESET CABINET RECORDS" in the Options area
if (appCode.includes('<Award size={14} />')) {
  appCode = appCode.replace(
    /(\<\/button\>\s*)(<\/div>\s*\{\/\* SYSTEM GUIDELINES \*\/})/g,
    `$1
            {isBackCloset && (
              <button
                onClick={() => {
                  const evt = new CustomEvent("leaveroom");
                  window.dispatchEvent(evt);
                  window.location.reload();
                }}
                className="mt-2 text-xs font-mono font-bold text-red-500 hover:text-red-400 transition-colors flex items-center gap-2 justify-center border border-red-500/50 py-3 rounded-lg bg-red-500/10 hover:bg-red-500/20 cursor-pointer"
              >
                !!! LEAVE BACK CLOSET !!!
              </button>
            )}
            $2`
  );
}

fs.writeFileSync('src/App.tsx', appCode);
